var searchData=
[
  ['validateuser_117',['validateUser',['../classcom_1_1mycompany_1_1ssproject_1_1LoginController.html#a9f6f3f54db8b6f95f6e4d45782d3c606',1,'com::mycompany::ssproject::LoginController']]]
];
