var searchData=
[
  ['whoamicontroller_81',['whoamiController',['../classcom_1_1mycompany_1_1ssproject_1_1whoamiController.html',1,'com::mycompany::ssproject']]]
];
