var searchData=
[
  ['whoamicontroller_56',['whoamiController',['../classcom_1_1mycompany_1_1ssproject_1_1whoamiController.html',1,'com::mycompany::ssproject']]],
  ['whoamicontroller_2ejava_57',['whoamiController.java',['../whoamiController_8java.html',1,'']]]
];
