var searchData=
[
  ['getdirectory_20',['getDirectory',['../classcom_1_1mycompany_1_1ssproject_1_1DataSingleton.html#a0e775e51d5d7d3d485e932b682b800a9',1,'com::mycompany::ssproject::DataSingleton']]],
  ['getinstance_21',['getInstance',['../classcom_1_1mycompany_1_1ssproject_1_1DataSingleton.html#ae1f7924a947cc5eb4105e48e5189bbb9',1,'com::mycompany::ssproject::DataSingleton']]],
  ['getpassword_22',['getPassword',['../classcom_1_1mycompany_1_1ssproject_1_1DataSingleton.html#a8b9508d282d7d64223fc00aa0e242a0c',1,'com::mycompany::ssproject::DataSingleton']]],
  ['getuserid_23',['getUserId',['../classcom_1_1mycompany_1_1ssproject_1_1DataSingleton.html#aea54acd43fcdd2cf4d66bd57194043ec',1,'com::mycompany::ssproject::DataSingleton']]],
  ['getusername_24',['getUserName',['../classcom_1_1mycompany_1_1ssproject_1_1DataSingleton.html#a4eca0977377a08d80dda33f679989062',1,'com::mycompany::ssproject::DataSingleton']]]
];
